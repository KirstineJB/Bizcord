﻿namespace ProfileService.Api.Messaging;

public class MessageClientOptions
{

    public string ConnectionString { get; set; } = string.Empty;
}